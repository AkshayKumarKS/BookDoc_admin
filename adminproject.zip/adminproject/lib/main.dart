import 'package:adminproject/addingpage.dart';
import 'package:adminproject/home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Firebase.initializeApp(
      options: FirebaseOptions(
          apiKey: "AIzaSyAJ_ltekoautAP-i0zpBL8J5o7qaRzYQ54",
          appId: "1:802992401132:android:1130b05b077682bb0653c9",
          messagingSenderId: "802992401132",
          projectId: "progect-80cea",
      storageBucket: "progect-80cea.appspot.com",
      ));
  runApp(MaterialApp(
    routes: {
      'UPDATE':(context)=>add(),
    },
    debugShowCheckedModeBanner: false,
    home: admin(),
  ));
}

class admin extends StatefulWidget {
  const admin({super.key});

  @override
  State<admin> createState() => _adminState();
}

class _adminState extends State<admin> {

  TextEditingController id = TextEditingController();
  TextEditingController pass = TextEditingController();



  @override
  Widget build(BuildContext context) {

    login()async {
      try {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
            email: id.text, password: pass.text);
        Navigator.push(context, MaterialPageRoute(builder: (context) => home(),));
        print("login Successful");
      }catch (e){
        print("error$e");
      }
    }
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("lib/images/download (2).jpg"),
                  fit: BoxFit.fill)),
          child: Column(
            children: [
              SizedBox(
                height: 350,
              ),
              Padding(
                padding: const EdgeInsets.all(40),
                child: TextField(controller: id,
                  decoration: InputDecoration(
                    labelText: "ID",
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(40),
                child: TextField(controller: pass,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Password",
                  ),
                ),
              ),
              ElevatedButton(
                  onPressed: () {
                    // Navigator.push(
                    //     context,
                    //     MaterialPageRoute(
                    //       builder: (context) => home(),
                    //     ));
                    login();
                  },
                  child: Text("Login"))
            ],
          ),
        ),
      ),
    );
  }
}
